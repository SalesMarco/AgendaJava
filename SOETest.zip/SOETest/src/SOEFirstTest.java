import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.remote.DesiredCapabilities;


import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;

public class SOEFirstTest {
	
	public static AppiumDriver<MobileElement> driver = null;
	
	public static void main(String[] args) {
		
		setUp("15181521650512","4.4.3","com.mobile.estafeta","com.outsystems.android.SplashScreen");
		
		LoginController loginController = LoginController.getInstance(driver);
		
		@SuppressWarnings("rawtypes")
		TouchAction action = new TouchAction(driver);
		
		/* Si la pantalla de login est� disponible, entonces haz las operaciones correspondientes a ella */
		
		if(loginController != null) {
			loginController.init("//android.widget.EditText[@instance=1]", "//android.widget.Button[@content-desc='Entrar']", 
					"//android.widget.Button[@content-desc=\"Supervisor\"]", "//android.widget.Button[@content-desc=\"Limpiar\"]");
			//C�digo que habilita el escaneo del dispositivo
		
			moverTouchHacia(action,479,428,152,428);
			presionarTouch(action,219,445);
			moverTouchHacia(action,152,428,479,428);
			
			loginController.contrasenia.sendKeys("0077");
			loginController.botonEntrar.click();
			driver.findElement(By.id("button1")).click();
			loginController.reset();
		}
		
		esperarCarga(3000);
	
		CargaController cargaController = CargaController.getInstance(driver);
		
		if(cargaController != null) {
			cargaController.init("//android.widget.Button[@content-desc='Carga ']");
			cargaController.botonCarga.click();
			cargaController.reset();
		}
		
		esperarCarga(3000);
		
		RegistroContenedorController registroContenedorController = RegistroContenedorController.getInstance(driver);
		
		if(registroContenedorController != null) {
			registroContenedorController.init("//android.widget.EditText[@instance=0]", "//android.widget.EditText[@instance=1]", "//android.widget.EditText[@instance=2]",
					"//android.widget.Button[@content-desc=\"Seleccione una nave...\"]", "//android.widget.Button[@content-desc=\"Seleccione una ruta...\"]", "//android.widget.Button[@content-desc=\"Aceptar\"]");
		
		
			registroContenedorController.contenedor1.sendKeys("C22EM1234");
			registroContenedorController.contenedor2.sendKeys("C22EM4321");
			driver.hideKeyboard();
		
			/* Se selecciona la lista de las naves disponibles para posteriormente seleccionar el segundo elemento
		   	de la lista ya que el primero es el t�tulo de la misma. 
			 */
			registroContenedorController.botonListaCheckIn.click();
			driver.findElement(By.xpath("//android.widget.ListView/android.widget.TextView[2]")).click();
		
			/*Aqu� hay que resaltar que la lista sobrepasa el tama�o de la pantalla, entonces
		  	si se deseara seleccionar un elemento fuera de pantalla primero se tendr�a que 
		  	bajar la lista con un touchaction. 
			 */
			registroContenedorController.botonRuta.click();
			driver.findElement(By.xpath("//android.widget.ListView/android.widget.TextView[5]")).click();
		
			registroContenedorController.botonAceptar.click();
			registroContenedorController.reset();
		}
		
		esperarCarga(3000);
		
		OpcionesController opcionesController = OpcionesController.getInstance(driver);
		
		if(opcionesController != null) {
			opcionesController.init("//android.widget.Button[@content-desc=\"ECON \"]","//android.widget.Button[@content-desc=\"manifiesto\"]","//android.widget.Button[@content-desc=\"Rebastecimiento\"]");
			opcionesController.botonECON.click();
			opcionesController.reset();
		}
		
		esperarCarga(3000);
		
		
		ArrayList<String> cajasDanadas = null;
		
		ManifiestoECONController manifiestoECONController = ManifiestoECONController.getInstance(driver);
		if(manifiestoECONController != null) {
			manifiestoECONController.init("//android.widget.EditText[@instance=0]","//android.widget.EditText[@instance=1]","//android.widget.EditText[@instance=2]",
					"//android.widget.Button[@content-desc=\"Aceptar\"]","//android.widget.Button[@content-desc=\"Guardar\"]");
			manifiestoECONController.insertar(3);
			manifiestoECONController.botonGuardar.click();
			manifiestoECONController.botonSi = manifiestoECONController.initElement("//android.widget.Button[@content-desc=\"Si\"]");
			manifiestoECONController.botonNo = manifiestoECONController.initElement("//android.widget.Button[@content-desc=\"no\"]");
			manifiestoECONController.botonCancelar = manifiestoECONController.initElement("//android.widget.Button[@content-desc=\"Cancelar\"]");
			/*Si se deseara continuar sin cajas da�adas esta secci�n se quitar�a y se pondr�a 
			 * manifiestoECONController.botonNo.click();
			 */
			
			manifiestoECONController.botonSi.click();
			cajasDanadas = new ArrayList<String>(manifiestoECONController.cajas);
			Collections.shuffle(cajasDanadas);
			manifiestoECONController.reset();
		}
		
		esperarCarga(3000);
		
		/* En esta parte se insertan cajas da�adas de prueba, as� como las fotos de la evidencia */
		
		for (int i = 0; i < new Random().nextInt(cajasDanadas.size()) + 1 ; i++){
			
			CajasDanadasController cajasDanadasController = CajasDanadasController.getInstance(driver);
			if(cajasDanadasController != null) {
				cajasDanadasController.init("//android.widget.EditText[@instance=0]", "//android.widget.Button[@content-desc=\"Aceptar \"]", "//android.widget.Button[@content-desc=\"Ir a autorizar\"]");
				cajasDanadasController.numeroCaja.sendKeys(cajasDanadas.get(i));
				cajasDanadasController.botonAceptar.click();
				cajasDanadasController.botonConfirmarAceptar = cajasDanadasController.initElement("//android.widget.Button[@instance=1]");
				cajasDanadasController.botonConfirmarCancelar = cajasDanadasController.initElement("//android.widget.Button[@instance=0]");
				cajasDanadasController.botonConfirmarAceptar.click();
				cajasDanadasController.reset();
			}
			
			esperarCarga(2000);
			
			FotoController fotoController = FotoController.getInstance(driver);
			if(fotoController != null) 
				fotoController.init("//android.widget.Button[@instance=0]", "ACEPTAR FOTO", "//android.widget.Button[@instance=1]");
				
			
			
			for(int j = 0; j < new Random().nextInt(5) + 1; j++) {
				
				fotoController.botonTomarFoto.click();
					
				CamaraController camaraController = CamaraController.getInstance(driver);
				if(camaraController != null) {
					camaraController.init("com.android.camera2:id/shutter_button");
					camaraController.botonCapturar.click();
					camaraController.botonAceptar = camaraController.initElement("com.android.camera2:id/btn_done");
					camaraController.botonAceptar.click();
					camaraController.reset();
				}
				
				esperarCarga(3000);
				fotoController.botonAceptarFoto.click();
				esperarCarga(1500);
			
										
			}
			
			//scrollDown();
			fotoController.botonTerminar.click();
			esperarCarga(1500);
			
			
		}
		
		
		
		
		
	}
	
	public static void setUp(String udid,String androidVersion,String appPackage, String appActivity) {
		
		//Set the Desired Capabilities
				DesiredCapabilities caps = new DesiredCapabilities();
				caps.setCapability("deviceName", "My Phone");
				caps.setCapability("udid", udid); //adb devices
				caps.setCapability("platformName", "Android");
				caps.setCapability("platformVersion", androidVersion);
				caps.setCapability("appPackage", appPackage);
				caps.setCapability("appActivity", appActivity);
				caps.setCapability("noReset", "true");
				//Instantiate Appium Driver
				try {
					driver = new AndroidDriver<MobileElement>(new URL("http://0.0.0.0:4723/wd/hub"), caps);
				} catch (MalformedURLException e) {
					System.out.println(e.getMessage());
				}
				//Added 10 seconds wait so that the app loads completely before starting with element identification
				try {
					Thread.sleep(10000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
		
	}

	@SuppressWarnings("rawtypes")
	public static void presionarTouch(TouchAction action,int x1,int y1) {
		action.press(PointOption.point(x1,y1))
			.waitAction(WaitOptions.waitOptions(Duration.ofMillis(1000)))
			.release()
			.perform();
	}
	
	@SuppressWarnings("rawtypes")
	public static void moverTouchHacia(TouchAction action, int x1, int y1, int x2, int y2) {
		action.press(PointOption.point(x1,y1))
			.waitAction(WaitOptions.waitOptions(Duration.ofMillis(1000)))
			.moveTo(PointOption.point(x2,y2))
			.release()
			.perform();
	}
	
	public static void esperarCarga(int milisec) {
		try {
			Thread.sleep(milisec);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	@SuppressWarnings("rawtypes")
	public static void scrollDown()  {

	    //The viewing size of the device
	    Dimension size = driver.manage().window().getSize();

	    //x position set to mid-screen horizontally
	    int width = size.width / 2;

	    //Starting y location set to 80% of the height (near bottom)
	    int startPoint = (int) (size.getHeight() * 0.80);

	    //Ending y location set to 1% of the height (almost top)
	    int endPoint = (int) (size.getHeight() * 0.01);

	    new TouchAction(driver).press(PointOption.point(width, startPoint)).waitAction(WaitOptions.waitOptions(Duration.ofMillis(2000))).moveTo(PointOption.point(width, endPoint)).release().perform();

	}

}
